<template>
  <div v-if="userProfile === 'admin' || userProfile === 'super'">
    <q-card bordered>
      <q-card-section>
        <div class="text-h6 q-px-sm">Relatório de Tickets</div>
      </q-card-section>
      <q-card-section class="q-pt-none">
        <fieldset>
          <legend class="q-px-sm">Filtros (Data de criação do ticket)</legend>
          <div class="row q-gutter-md items-end" >
            <div class="col-grow">
              <label>Início</label>
              <DatePick
                dense
                v-model="pesquisa.startDate"
              />
              <!-- <q-input
                dense
                v-model="pesquisa.startDate"
                mask="####-##-##"
                type="date"
              /> -->
            </div>
            <div class="col-grow">
              <label>Final</label>
              <DatePick
                dense
                v-model="pesquisa.endDate"
              />
              <!-- <q-input
                dense
                v-model="pesquisa.endDate"
                mask="####-##-##"
                type="date"
              /> -->
            </div>
            <div class="col-grow text-center">
              <q-btn
                class="q-mr-sm"
                color="primary"
                label="Gerar"
                icon="refresh"
                @click="gerarRelatorio"
              />
              <q-btn
                class="q-mr-sm"
                color="black"
                icon="print"
                label="Imprimir"
                @click="printReport('tRelatorioTickets')"
              />
              <q-btn
                color="warning"
                label="Excel"
                @click="exportTable('tRelatorioTickets')"
              />
            </div>
          </div>
          <div class="row q-gutter-md items-end" style="margin-top: 10px">
            <div class="col-grow">
              <label>Status</label>
              <q-select
                v-model="pesquisa.status"
                dense
                :options="statusOptions"
                multiple
                emit-value
                map-options
                label="Selecione os Status"
              />
            </div>
            <div class="col-grow">
              <label>Conexões</label>
              <q-select
                v-model="pesquisa.whatsappId"
                dense
                :options="cSessionsOptions"
                multiple
                emit-value
                map-options
                label="Selecione as Conexões"
              />
            </div>
            <div class="col-grow">
              <label>Filas</label>
              <q-select
                v-model="pesquisa.queues"
                dense
                :options="queuesOptions"
                multiple
                emit-value
                map-options
                label="Selecione as filas"
                :loading="loadingFilas"
              />
            </div>
            <div class="col-grow">
              <label>Usuários</label>
              <q-select
                v-model="pesquisa.userId"
                dense
                :options="usuariosOptions"
                emit-value
                map-options
                label="Selecione o usuário"
                :loading="loadingUsuarios"
              />
            </div>
            <div class="col-grow">
              <label>Canais</label>
              <q-select
                v-model="pesquisa.channel"
                dense
                :options="channelOptions"
                multiple
                emit-value
                map-options
                label="Selecione os canais"
              />
            </div>
          </div>
        </fieldset>
      </q-card-section>
    </q-card>

    <div class="row">
      <div class="col-xs-12 q-mt-sm">
        <div
          class="tableLarge q-ma-sm q-markup-table q-table__container q-table__card q-table--cell-separator q-table--flat q-table--bordered q-table--no-wrap"
        >
          <table id="tableRelatorioTickets" class="q-pb-md q-table q-tabs--dense">
            <thead>
              <tr>
                <td v-for="col in columns" :key="col.name">
                  {{ col.label }}
                </td>
              </tr>
            </thead>
            <tbody>
              <tr v-for="ticket in tickets" :key="ticket.id">
                <td v-for="col in columns" :key="col.name + '-' + ticket.id">
                  {{ col.format ? col.format(ticket[col.field]) : ticket[col.field] || "N/A" }}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import XLSX from "xlsx";
import { RelatorioTiketss } from "src/service/estatisticas";
import { ListarFilas } from "src/service/filas";
import { ListarUsuarios } from "src/service/user"
import { mapGetters } from 'vuex';

export default {
  name: "RelatorioTickets",
  data() {
    return {
      userProfile: "user",
      tickets: [],
      usuariosOptions: [],
      loadingUsuarios: false,
      columns: [
        { name: "id", label: "ID", field: "id", align: "center" },
        { name: "status", label: "Status", field: "status", align: "center", format: this.formatStatus },
        {
          name: 'contactName',
          label: 'Nome',
          field: 'contact',
          align: 'center',
          style: 'width: 200px',
          format: (v) => {
            return v ? v.name : ''
          }
        },
        {
          name: 'contactNumber',
          label: 'Número',
          field: 'contact',
          align: 'center',
          style: 'width: 200px',
          format: (v) => {
            return v ? v.number : ''
          }
        },
        {
          name: 'whatsapp',
          label: 'Conexão',
          field: 'whatsapp',
          align: 'center',
          style: 'width: 200px',
          format: (v) => {
            return v ? v.name : ''
          }
        },
        { name: "lastMessage", label: "Última Mensagem", field: "lastMessage", align: "left" },
        {
          name: "unreadMessages",
          label: "Mensagens Não Lidas",
          field: "unreadMessages",
          align: "center",
          format: this.formatNaoLida
        },
        {
          name: "createdAt",
          label: "Data de Criação",
          field: "createdAt",
          align: "center",
          format: (v) => new Date(v).toLocaleString(),
        }
      ],
      pesquisa: {
        startDate: "",
        endDate: "",
        status: [],
        queues: [],
        channel: [],
        whatsappId: [],
      },
      statusOptions: [
        { label: "Aberto", value: "open" },
        { label: "Fechado", value: "closed" },
        { label: "Pendente", value: "pending" },
      ],
      channelOptions: [
        { label: 'WhatsApp Oficial (WABA)', value: 'waba' },
        { label: 'WhatsApp Baileys (QRCode)', value: 'baileys' },
        { label: 'WhatsApp WebJs (QRCode)', value: 'whatsapp' },
        { label: 'WhatsApp Meow (QRCode)', value: 'meow' },
        { label: 'Telegram', value: 'telegram' },
        { label: 'Facebook (Hub)', value: 'hub_facebook' },
        { label: 'Instagram (Hub)', value: 'hub_instagram' },
      ],
      queuesOptions: [],
      loadingFilas: false,
    };
  },
  computed: {
    ...mapGetters(['whatsapps']),
    cSessions() {
      return this.whatsapps.filter(w => !w.isDeleted)
    },
    cSessionsOptions() {
      return this.cSessions.map(w => ({ label: w.name, value: w.id, type: w.type }))
    }
  },
  methods: {
    formatNaoLida(unread){
      if(unread){
        return 'Sim'
      } else {
        return 'Não'
      }
    },
    formatStatus(status) {
      switch (status) {
        case 'open':
          return 'Aberto';
        case 'closed':
          return 'Fechado';
        case 'pending':
          return 'Pendente';
        case 'schedule':
          return 'Agendado';
        default:
          return status;
      }
    },
    async listarUsuarios() {
      try {
        this.loadingUsuarios = true;
        const { data } = await ListarUsuarios();
        this.usuariosOptions = data.users
          .filter((user) => user.profile !== "superadmin")
          .map((user) => ({
            label: user.name,
            value: user.id,
          }));
      } catch (error) {
        console.error(error);
        this.$q.notify({ color: "negative", message: "Problema ao carregar usuários" });
      } finally {
        this.loadingUsuarios = false;
      }
    },
    async listarFilas() {
      try {
        this.loadingFilas = true;
        const { data } = await ListarFilas();
        this.queuesOptions = data.map((fila) => ({
          label: fila.queue,
          value: fila.id,
        }));
      } catch (error) {
        console.error("Erro ao listar filas:", error);
        this.$q.notify({ color: "negative", message: "Erro ao carregar filas" });
      } finally {
        this.loadingFilas = false;
      }
    },
    async gerarRelatorio() {
      if (!this.pesquisa.startDate || !this.pesquisa.endDate) {
        this.$q.notify({ color: "negative", message: "Preencha as datas para gerar o relatório" });
        return;
      }
      // if (!this.pesquisa.userId) {
      //   this.$q.notify({ color: 'negative', message: 'Selecione um usuário para gerar o relatório' });
      //   return;
      // }
      const params = {
        ...this.pesquisa,
        userId: this.pesquisa.userId || null,
        channel: this.pesquisa.channel.length ? this.pesquisa.channel : null,
        whatsappId: this.pesquisa.whatsappId.length ? this.pesquisa.whatsappId : null,
      };

      const { data } = await RelatorioTiketss(params);
      console.log('data >>>>>>>>', data)
      this.tickets = data.tickets || [];
    },
    exportTable() {
      const table = document.getElementById("tableRelatorioTickets");
      const worksheet = XLSX.utils.table_to_sheet(table);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Relatório de Tickets");
      XLSX.writeFile(workbook, "Relatorio-Tickets.xlsx");
    },
    printReport() {
      window.print();
    },
  },
  async mounted() {
    this.userProfile = localStorage.getItem("profile");
    await this.listarUsuarios(); // Carrega a lista de usuários
    await this.listarFilas(); // Carrega a lista de filas
  },
};
</script>

<style scoped>
.tableLarge {
  max-height: calc(100vh - 220px);
  height: calc(100vh - 220px);
}
thead tr td {
  color: #000;
  background: lightgrey;
  position: sticky;
  top: 0;
  z-index: 1000;
}
</style>
