<template>
  <div v-if="userProfile === 'superadmin'">
    <q-page padding>
      <q-card flat bordered class="q-pa-md">
        <q-card-section class="text-center">
          <div class="text-h5 text-primary">Gerenciamento de Licença</div>
          <div class="text-subtitle1 q-mt-sm">
            Controle e ajuste de informações de licença.
          </div>
        </q-card-section>

        <q-separator spaced />

        <q-card-section class="q-pa-md">
          <q-list separator>
            <q-item>
              <q-item-section avatar>
                <q-icon name="verified" color="primary" size="md" />
              </q-item-section>
              <q-item-section>
                <q-item-label>Status da Licença:</q-item-label>
                <q-item-label caption>
                  <q-chip
                    outline
                    :color="license === 'enabled' ? 'positive' : 'negative'"
                  >
                    {{ license === 'enabled' ? 'Ativo' : 'Validando...' }}
                  </q-chip>
                </q-item-label>
              </q-item-section>
            </q-item>
            <q-item>
              <q-item-section avatar>
                <q-icon name="email" color="primary" size="md" />
              </q-item-section>
              <q-item-section>
                <q-item-label>E-mail:</q-item-label>
                <q-item-label caption>{{ email }}</q-item-label>
              </q-item-section>
            </q-item>
          </q-list>
        </q-card-section>

        <q-card-actions align="center">
          <q-btn
            label="Alterar Licença"
            color="primary"
            icon="edit"
            push
            @click="openEmailModal"
          />
        </q-card-actions>
      </q-card>

      <!-- Modal -->
      <q-dialog v-model="isEmailModalOpen" persistent>
        <q-card>
          <q-card-section>
            <div class="text-h6 text-primary">Alterar E-mail</div>
            <div class="text-subtitle2 q-mt-sm">
              Atualize o e-mail associado à licença.
            </div>
          </q-card-section>

          <q-card-section>
            <q-input
              v-model="email"
              label="Novo E-mail"
              outlined
              dense
              :rules="[val => !!val || 'O e-mail é obrigatório']"
            />
          </q-card-section>

          <q-card-actions align="right">
            <q-btn flat label="Cancelar" color="negative" @click="closeEmailModal" />
            <q-btn
              flat
              label="Salvar"
              color="positive"
              @click="saveEmail"
              :loading="loading"
            />
          </q-card-actions>
        </q-card>
      </q-dialog>
    </q-page>
  </div>
</template>

<script>
import { ListarTenants, AlterarEmail } from "src/service/tenants";
import { MostrarCores } from "src/service/empresas";

export default {
  name: "Assinaturas",
  data() {
    return {
      isEmailModalOpen: false,
      email: "",
      license: "",
      colors: {
        neutral: "#E0E1E2",
        primary: "#5c67f2",
        secondary: "#f5f5f9",
        accent: "#ff5c93",
        warning: "#ffeb3b",
        negative: "#f44336",
        positive: "#25d366",
        light: "#8DB1DD",
      },
      userProfile: "user",
      loading: false,
    };
  },
  methods: {
    async listarTenants() {
      const { data } = await ListarTenants();
      this.email = data[0].tenantEmail;
      this.license = data[0].tenantLicense;
    },
    openEmailModal() {
      this.isEmailModalOpen = true;
    },
    closeEmailModal() {
      this.isEmailModalOpen = false;
    },
    async saveEmail() {
      try {
        this.loading = true;
        const response = await AlterarEmail({ tenantEmail: this.email });
        this.$q.notify({ type: "positive", message: "E-mail atualizado com sucesso!" });
        this.closeEmailModal();
        this.listarTenants();
      } catch (error) {
        if(error.data.error === 'ERR_LIMIT_MAX'){
          this.$q.notify({
            type: 'negative',
            message: 'Foram realizadas muitas tentativas de ativação. Tente novamente em 1 minuto',
            position: 'top',
            progress: true
          })
        }
        console.error(error);
        // this.$q.notify({ type: "negative", message: "Erro ao atualizar o e-mail." });
      } finally {
        this.loading = false;
      }
    },
    async loadColors() {
      try {
        const response = await MostrarCores();
        if (response.status === 200) {
          const companyData = response.data[0];
          const colorsArray = companyData.systemColors;

          this.colors = colorsArray.reduce((acc, colorObj) => {
            const key = colorObj.label.toLowerCase();
            acc[key] = colorObj[key]; // Ajuste das cores
            return acc;
          }, {});

          const root = document.documentElement;
          root.style.setProperty("--q-neutral", this.colors.neutral);
          root.style.setProperty("--q-primary", this.colors.primary);
          root.style.setProperty("--q-secondary", this.colors.secondary);
          root.style.setProperty("--q-accent", this.colors.accent);
          root.style.setProperty("--q-warning", this.colors.warning);
          root.style.setProperty("--q-negative", this.colors.negative);
          root.style.setProperty("--q-positive", this.colors.positive);
          root.style.setProperty("--q-light", this.colors.light);
        } else {
          console.error("Erro ao carregar as cores");
        }
      } catch (error) {
        console.error("Erro ao carregar as cores:", error);
      }
    },
  },
  mounted() {
    this.listarTenants();
    this.userProfile = localStorage.getItem("profile");
    this.loadColors();
  },
};
</script>

<style lang="scss" scoped>
.q-card {
  max-width: 500px;
  margin: 0 auto;
}
.q-btn {
  font-size: 16px;
}
.q-input {
  margin-top: 15px;
}
.q-dialog {
  min-width: 300px;
}
</style>
